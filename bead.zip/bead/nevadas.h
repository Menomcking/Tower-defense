#ifndef NEVADAS_H
#define NEVADAS_H
    char *nevadas(int nevhossz);
#endif