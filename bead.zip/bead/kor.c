#include <stdio.h>
#include <stdbool.h>
#include "kirajzol.h"
#include "kor_vege.h"

//Itt fut a játék fő része, addig ismételgeti a kirazjolást amíg vége nincs a körnek.
void kor(int eletek, int pontszam, int elkoltheto_pontok, Torony *tornyok, Ellenfel *ellenfelek, int kori, int kor_lepes){
    /*int legyozott_ellenfelek = 0;
    while(eletek > 3 && legyozott_ellenfelek < 5){
        kirajzol(eletek, pontszam, elkoltheto_pontok, tornyok, ellenfelek, kori, kor_lepes);
        for(int i = 0; i < 9; i++){
            if(tornyok[1].hatotav <= ellenfelek[i].)

        }
        
    }*/
}