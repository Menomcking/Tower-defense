#include "jatek_vege.h"
#ifndef TEMP_RST_H
#define TEMP_RST_H
    void temp_rst(adat *temp);
#endif