#ifndef JATEK_VEGE_H
#define JATEK_VEGE_H
    typedef struct Adat{
    char *nev;
    int pont;
    }adat;
    void jatek_vege(int pontok, char *neve);
#endif