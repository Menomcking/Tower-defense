#include "ellenfel_init.h"
#include "kirajzol.h"
#ifndef KOR_VEGE_H
#define KOR_VEGE_H
    void kor_vege(int eletek, int pontszam, int elkoltheto_pontok, Torony *tornyok, Ellenfel *ellenfelek, int kori, char *nev);
#endif